import os
import random
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage import zoom
from torch.utils.data import Dataset
from PIL import Image  # 引入PIL库用于读取tif和png图像

def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label

def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
            
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            # 这里的order=3用于图像插值，order=0用于标签插值（防止产生非整数标签）
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
            
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample

class Octa_SS_dataset(Dataset):
    def __init__(self, base_dir, split, transform=None):
        """
        base_dir: 数据集根目录，例如 /home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS
        split: 'train' 或 'test'
        """
        self.transform = transform
        self.split = split
        self.data_dir = base_dir
        
        # 定义原图和Mask的具体路径
        self.img_dir = os.path.join(self.data_dir, self.split, 'original')
        self.seg_dir = os.path.join(self.data_dir, self.split, 'segment')
        
        # 自动读取original文件夹下的所有.tif文件作为样本列表
        # 假设文件名对应关系：1.tif (image) -> 1.png (label)
        self.sample_list = [
            os.path.splitext(f)[0] 
            for f in os.listdir(self.img_dir) 
            if f.endswith('.tif')
        ]
        
        # 如果需要，可以对列表进行排序，保证顺序一致
        self.sample_list.sort()

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        file_name = self.sample_list[idx]
        
        # 1. 构建文件路径：注意原图是tif，标签是png
        img_path = os.path.join(self.img_dir, file_name + '.tif')
        label_path = os.path.join(self.seg_dir, file_name + '.png')
        
        # 2. 读取图像并转为灰度图 ('L')
        # 如果你的原图是RGB彩色，去掉 .convert('L')，但通常OCTA血管图是灰度的
        image = Image.open(img_path).convert('L')
        label = Image.open(label_path).convert('L')
        
        # 3. 转为numpy数组并归一化
        image = np.array(image).astype(np.float32) / 255.0  # 归一化到 [0, 1]
        label = np.array(label).astype(np.float32) 
        
        # 4. 处理标签：确保标签是 0 和 1 (二值化)
        # 因为读取png时像素可能是0和255，这里做一个阈值处理
        label = label / 255.0
        label[label >= 0.5] = 1
        label[label < 0.5] = 0
        
        sample = {'image': image, 'label': label}
        
        # 5. 应用变换 (仅在训练集使用 RandomGenerator)
        if self.transform:
            sample = self.transform(sample)
        
        # 如果没有transform（例如测试集），需要手动转为Tensor并增加channel维度
        # 这样保持和 RandomGenerator 输出格式一致
        if not self.transform and self.split == "test":
             # 增加 channel 维度 (H, W) -> (1, H, W)
             image_tensor = torch.from_numpy(image).unsqueeze(0).float()
             label_tensor = torch.from_numpy(label).long()
             sample = {'image': image_tensor, 'label': label_tensor}

        sample['case_name'] = file_name
        return sample