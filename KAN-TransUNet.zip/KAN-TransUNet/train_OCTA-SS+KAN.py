import argparse
import logging
import os
import random
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import subprocess  # 【修改1】引入 subprocess 用于调用系统命令
from networks.vit_seg_modeling import VisionTransformer as ViT_seg
from networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg
# 引入我们之前修改过的 trainer
from trainer import trainer_synapse, trainer_OCTA_SS

parser = argparse.ArgumentParser()

parser.add_argument('--output_dir', type=str, 
                    default='/home/ly_s/WORK/Segment/TransUNet-main/model/OCTA_SSm1', 
                    help='output dir')
parser.add_argument('--root_path', type=str,
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS', help='root dir for data')
parser.add_argument('--dataset', type=str,
                    default='OCTA-SS', help='experiment_name')
parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')
parser.add_argument('--num_classes', type=int,
                    default=2, help='output channel of network')
parser.add_argument('--max_iterations', type=int,
                    default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int,
                    default=150, help='maximum epoch number to train')

# parser.add_argument('--batch_size', type=int,
#                     default=24, help='batch_size per gpu')

parser.add_argument('--batch_size', type=int,
                    default=4, help='batch_size per gpu')

parser.add_argument('--n_gpu', type=int, default=1, help='total gpu')
parser.add_argument('--deterministic', type=int,  default=1,
                    help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.01,
                    help='segmentation network learning rate')
parser.add_argument('--img_size', type=int,
                    default=224, help='input patch size of network input')
parser.add_argument('--seed', type=int,
                    default=1234, help='random seed')
parser.add_argument('--n_skip', type=int,
                    default=3, help='using number of skip-connect, default is num')
parser.add_argument('--vit_name', type=str,
                    default='R50-ViT-B_16', help='select one vit model')
parser.add_argument('--vit_patches_size', type=int,
                    default=16, help='vit_patches_size, default is 16')
args = parser.parse_args()

# 【修改2】定义获取最大显存 GPU ID 的函数
def get_device_id_with_max_memory():
    try:
        # 调用 nvidia-smi 查询所有 GPU 的剩余显存 (单位 MiB)
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=memory.free', '--format=csv,nounits,noheader'],
            stdout=subprocess.PIPE, encoding='utf-8'
        )
        # 将输出转换为整数列表 [gpu0_free, gpu1_free, ...]
        free_memory = [int(x) for x in result.stdout.strip().split('\n')]
        
        # 找到剩余显存最大的索引
        max_mem = max(free_memory)
        best_gpu_id = free_memory.index(max_mem)
        
        print(f"Detected GPUs free memory: {free_memory}")
        print(f"Auto-selecting GPU {best_gpu_id} with {max_mem} MiB free memory.")
        return best_gpu_id
    except Exception as e:
        print(f"Failed to auto-select GPU: {e}. Fallback to GPU 0.")
        return 0

if __name__ == "__main__":
    # ==============================================================================
    # 【修改3】在程序最开始执行自动选择 GPU 逻辑
    # ==============================================================================
    best_gpu_id = get_device_id_with_max_memory()
    
    # 设置环境变量，让 PyTorch 只"看到"这张显卡
    # 这样对于 PyTorch 来说，这张卡就是 "cuda:0"
    os.environ["CUDA_VISIBLE_DEVICES"] = str(best_gpu_id)
    
    # 防止显存碎片化 (针对您之前的 OOM 问题)
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"

    # 因为通过 CUDA_VISIBLE_DEVICES 屏蔽了其他显卡，PyTorch 现在只能看到 1 张卡
    # 必须强制将 n_gpu 设置为 1，否则 DataParallel 会出错或导致显存计算错误
    print(f"Force setting args.n_gpu = 1 (Training on single best GPU: {best_gpu_id})")
    args.n_gpu = 1
    # ==============================================================================

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    
    dataset_name = args.dataset
    
    dataset_config = {
        'Synapse': {
            'root_path': '../data/Synapse/train_npz',
            'list_dir': './lists/lists_Synapse',
            'num_classes': 9,
        },
        'OCTA-SS': {
            'root_path': '/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS',
            'list_dir': '', 
            'num_classes': 2,
        },
    }
    
    if dataset_name not in dataset_config:
        raise ValueError("Unknown dataset name: {}".format(dataset_name))

    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.root_path = dataset_config[dataset_name]['root_path']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    
    args.is_pretrain = False 
    
    args.exp = 'TU_' + dataset_name + str(args.img_size)
    
    base_snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model"
    snapshot_path = os.path.join(base_snapshot_path, args.exp, 'TU')
    
    snapshot_path = snapshot_path + '_pretrain' if args.is_pretrain else snapshot_path
    snapshot_path += '_' + args.vit_name
    snapshot_path = snapshot_path + '_skip' + str(args.n_skip)
    snapshot_path = snapshot_path + '_vitpatch' + str(args.vit_patches_size) if args.vit_patches_size!=16 else snapshot_path
    snapshot_path = snapshot_path+'_'+str(args.max_iterations)[0:2]+'k' if args.max_iterations != 30000 else snapshot_path
    snapshot_path = snapshot_path + '_epo' +str(args.max_epochs) if args.max_epochs != 30 else snapshot_path
    snapshot_path = snapshot_path+'_bs'+str(args.batch_size)
    snapshot_path = snapshot_path + '_lr' + str(args.base_lr) if args.base_lr != 0.01 else snapshot_path
    snapshot_path = snapshot_path + '_'+str(args.img_size)
    snapshot_path = snapshot_path + '_s'+str(args.seed) if args.seed!=1234 else snapshot_path

    if not os.path.exists(snapshot_path):
        os.makedirs(snapshot_path)
        
    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip
    if args.vit_name.find('R50') != -1:
        config_vit.patches.grid = (int(args.img_size / args.vit_patches_size), int(args.img_size / args.vit_patches_size))
    
    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()
    
    trainer = {
        'Synapse': trainer_synapse,
        'OCTA-SS': trainer_OCTA_SS,
    }
    
    trainer[dataset_name](args, net, snapshot_path)