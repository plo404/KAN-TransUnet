import argparse
import logging
import os
import random
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import subprocess  # 引入 subprocess 用于自动选择 GPU
from networks.vit_seg_modeling0 import VisionTransformer as ViT_seg
from networks.vit_seg_modeling0 import CONFIGS as CONFIGS_ViT_seg

# 【修改1】引入 trainer_OCTA_3M
# 请确保 trainer.py 中已经添加了 trainer_OCTA_3M 函数
from trainer import trainer_synapse, trainer_OCTA_SS, trainer_OCTA_3M

parser = argparse.ArgumentParser()

parser.add_argument('--output_dir', type=str, 
                    default='/home/ly_s/WORK/Segment/TransUNet-main/model/OCTA_3M', 
                    help='output dir')

# [修改] 默认路径指向您的 OCTA_3M 数据集根目录
parser.add_argument('--root_path', type=str,
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M', help='root dir for data')

# [修改] 默认数据集名称改为 OCTA_3M
parser.add_argument('--dataset', type=str,
                    default='OCTA_3M', help='experiment_name')

parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')

# [修改] 二分类任务
parser.add_argument('--num_classes', type=int,
                    default=2, help='output channel of network')

parser.add_argument('--max_iterations', type=int,
                    default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int,
                    default=150, help='maximum epoch number to train')

# [修改] 默认 Batch Size 设为 4，防止 KAN/ViT 显存溢出
parser.add_argument('--batch_size', type=int,
                    default=4, help='batch_size per gpu')

parser.add_argument('--n_gpu', type=int, default=1, help='total gpu')
parser.add_argument('--deterministic', type=int,  default=1,
                    help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.01,
                    help='segmentation network learning rate')
parser.add_argument('--img_size', type=int,
                    default=224, help='input patch size of network input')
parser.add_argument('--seed', type=int,
                    default=1234, help='random seed')
parser.add_argument('--n_skip', type=int,
                    default=3, help='using number of skip-connect, default is num')

# [建议] 恢复默认使用 R50-ViT-B_16，这是标准的 TransUNet 配置
# 如果您确实想用 ViT-L_32，可以手动修改这里，但要注意显存占用会非常大




parser.add_argument('--vit_name', type=str,
                    default='ViT-L_32', help='select one vit model')


'''
    'ViT-B_16'
    'ViT-B_32'
    'ViT-L_16'
    'ViT-L_32'
    'ViT-H_14'
    'R50-ViT-B_16'
    'R50-ViT-L_16'
'''



# parser.add_argument('--vit_patches_size', type=int,
#                     default=16, help='vit_patches_size, default is 16')


parser.add_argument('--vit_patches_size', type=int,
                    default=32, help='vit_patches_size, default is 16')


args = parser.parse_args()


# ==============================================================================
# 自动选择显存最大的 GPU 功能函数
# ==============================================================================
def get_device_id_with_max_memory():
    try:
        # 调用 nvidia-smi 查询所有 GPU 的剩余显存
        result = subprocess.run(
            ['nvidia-smi', '--query-gpu=memory.free', '--format=csv,nounits,noheader'],
            stdout=subprocess.PIPE, encoding='utf-8'
        )
        free_memory = [int(x) for x in result.stdout.strip().split('\n')]
        max_mem = max(free_memory)
        best_gpu_id = free_memory.index(max_mem)
        print(f"Detected GPUs free memory: {free_memory}")
        print(f"Auto-selecting GPU {best_gpu_id} with {max_mem} MiB free memory.")
        return best_gpu_id
    except Exception as e:
        print(f"Failed to auto-select GPU: {e}. Fallback to GPU 0.")
        return 0

if __name__ == "__main__":

    # ------------------------------------------------------------------
    # 自动选择 GPU & 环境配置
    # ------------------------------------------------------------------
    best_gpu_id = get_device_id_with_max_memory()
    os.environ["CUDA_VISIBLE_DEVICES"] = str(best_gpu_id)
    # 防止显存碎片化
    os.environ["PYTORCH_CUDA_ALLOC_CONF"] = "expandable_segments:True"
    print(f"Force setting args.n_gpu = 1 (Training on single best GPU: {best_gpu_id})")
    args.n_gpu = 1
    # ------------------------------------------------------------------

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True

    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)
    
    dataset_name = args.dataset
    
    # 配置数据集信息
    dataset_config = {
        'Synapse': {
            'root_path': '../data/Synapse/train_npz',
            'list_dir': './lists/lists_Synapse',
            'num_classes': 9,
        },
        'OCTA-SS': {
            'root_path': '/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS',
            'list_dir': '', 
            'num_classes': 2,
        },
        # 【修改2】添加 OCTA_3M 配置
        'OCTA_3M': {
            'root_path': '/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M',
            'list_dir': '', 
            'num_classes': 2,
        },
    }
    
    if dataset_name not in dataset_config:
        raise ValueError("Unknown dataset name: {}".format(dataset_name))

    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.root_path = dataset_config[dataset_name]['root_path']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    
    # 不使用预训练权重 (KAN 结构不匹配)
    args.is_pretrain = False 
    
    args.exp = 'TU_' + dataset_name + str(args.img_size)
    
    base_snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model"
    snapshot_path = os.path.join(base_snapshot_path, args.exp, 'TU')
    
    snapshot_path = snapshot_path + '_pretrain' if args.is_pretrain else snapshot_path
    snapshot_path += '_' + args.vit_name
    snapshot_path = snapshot_path + '_skip' + str(args.n_skip)
    snapshot_path = snapshot_path + '_vitpatch' + str(args.vit_patches_size) if args.vit_patches_size!=16 else snapshot_path
    snapshot_path = snapshot_path+'_'+str(args.max_iterations)[0:2]+'k' if args.max_iterations != 30000 else snapshot_path
    snapshot_path = snapshot_path + '_epo' +str(args.max_epochs) if args.max_epochs != 30 else snapshot_path
    snapshot_path = snapshot_path+'_bs'+str(args.batch_size)
    snapshot_path = snapshot_path + '_lr' + str(args.base_lr) if args.base_lr != 0.01 else snapshot_path
    snapshot_path = snapshot_path + '_'+str(args.img_size)
    snapshot_path = snapshot_path + '_s'+str(args.seed) if args.seed!=1234 else snapshot_path

    if not os.path.exists(snapshot_path):
        os.makedirs(snapshot_path)
        
    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip

    if args.vit_name.find('R50') != -1:
        config_vit.patches.grid = (int(args.img_size / args.vit_patches_size), int(args.img_size / args.vit_patches_size))
    
    # 【修复】手动指定 skip_channels，防止 KeyError
    if 'R50' in args.vit_name:
        config_vit.skip_channels = [512, 256, 64, 16]
    else:
        config_vit.skip_channels = [0, 0, 0, 0]

    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()

    # 注册 Trainer
    trainer = {
        'Synapse': trainer_synapse,
        'OCTA-SS': trainer_OCTA_SS,
        'OCTA_3M': trainer_OCTA_3M, # 【修改3】注册新的 trainer
    }
    
    trainer[dataset_name](args, net, snapshot_path)