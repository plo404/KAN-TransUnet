import os
import random
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage import zoom
from torch.utils.data import Dataset
from PIL import Image

# ============================================================================
# 数据增强部分 (保持与 OCTA_SS 完全一致)
# ============================================================================

def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label

def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
            
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            # order=3 用于图像插值，order=0 用于标签插值
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
            
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample


# ============================================================================
# OCTA_3M 数据集类
# ============================================================================

class OCTA_3M_dataset(Dataset):
    def __init__(self, base_dir, split, transform=None):
        """
        base_dir: 数据集根目录，例如 .../data/OCTA_3M
        split: 'train' 或 'test'
        """
        self.transform = transform
        self.split = split
        self.data_dir = base_dir
        
        # 1. 定义原图和Mask的具体路径
        # 按照您的要求:
        # 原图 -> original
        # 标签 -> segment
        self.img_dir = os.path.join(self.data_dir, self.split, 'original')
        self.mask_dir = os.path.join(self.data_dir, self.split, 'segment')
        
        # 检查目录是否存在，防止路径错误
        if not os.path.exists(self.img_dir):
            raise FileNotFoundError(f"Image directory not found: {self.img_dir}")
        if not os.path.exists(self.mask_dir):
            # 兼容处理：有些数据集可能叫 segenmt (如截图) 或 segment (如描述)
            # 这里优先信任您的描述 'segment'，如果找不到，提示用户
            raise FileNotFoundError(f"Mask directory not found: {self.mask_dir}")

        # 2. 读取所有图片文件列表
        # 这里做了兼容，支持 png, jpg, tif, bmp 等常见格式
        self.sample_list = []
        for f in os.listdir(self.img_dir):
            if f.lower().endswith(('.tif', '.png', '.jpg', '.jpeg', '.bmp')):
                self.sample_list.append(f)
        
        self.sample_list.sort()
        print(f"Found {len(self.sample_list)} images in {self.split} set (OCTA_3M).")

    def __len__(self):
        return len(self.sample_list)

    def __getitem__(self, idx):
        img_filename = self.sample_list[idx]
        basename = os.path.splitext(img_filename)[0]
        
        # 3. 寻找对应的 Mask 文件
        # 假设文件名一致 (例如 image.png -> image.png)
        # 或者 image.tif -> image.png
        
        mask_filename = None
        # 优先级 1: 寻找完全同名的文件
        if os.path.exists(os.path.join(self.mask_dir, img_filename)):
            mask_filename = img_filename
        # 优先级 2: 寻找同名但后缀为 png 的文件 (常见标签格式)
        elif os.path.exists(os.path.join(self.mask_dir, basename + '.png')):
            mask_filename = basename + '.png'
        # 优先级 3: 寻找同名但后缀为 bmp 的文件
        elif os.path.exists(os.path.join(self.mask_dir, basename + '.bmp')):
            mask_filename = basename + '.bmp'
        
        if mask_filename is None:
            # 如果找不到，打印详细错误帮助调试
            raise FileNotFoundError(f"Cannot find mask for image {img_filename} in {self.mask_dir}")

        # 4. 构建完整路径
        img_path = os.path.join(self.img_dir, img_filename)
        mask_path = os.path.join(self.mask_dir, mask_filename)
        
        # 5. 读取图像
        # OCTA 通常是灰度图，这里统一转为 'L' 模式
        image = Image.open(img_path).convert('L')
        label = Image.open(mask_path).convert('L')
        
        # 6. 转为 numpy 并归一化
        image = np.array(image).astype(np.float32) / 255.0  # [0, 1]
        label = np.array(label).astype(np.float32)
        
        # 7. 标签二值化 (0 和 1)
        # 即使标签图像是 0和255，除以255后变成 0和1
        label = label / 255.0
        label[label >= 0.5] = 1
        label[label < 0.5] = 0
        
        sample = {'image': image, 'label': label}
        
        # 8. 应用数据增强 (仅训练集)
        if self.transform:
            sample = self.transform(sample)
        
        # 9. 测试集处理 (如果没有 transform)
        # 增加 Channel 维度: (H, W) -> (1, H, W)
        if not self.transform and self.split == "test":
             image_tensor = torch.from_numpy(image).unsqueeze(0).float()
             label_tensor = torch.from_numpy(label).long()
             sample = {'image': image_tensor, 'label': label_tensor}

        sample['case_name'] = basename
        return sample