import argparse
import logging
import os
import random
import sys
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

# [修改点1] 导入 dataset_OCTA_SS.py
# 请检查 dataset_OCTA_SS.py 中的类名是 'OCTA_dataset' 还是 'Synapse_dataset' 还是其他名字
# 假设你的类名叫做 OCTA_dataset，如果不是，请修改 import 这里的名字
from datasets.dataset_OCTA_SS import Octa_SS_dataset 

from utils import test_single_volume
from networks.vit_seg_modeling import VisionTransformer as ViT_seg
from networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg

parser = argparse.ArgumentParser()

# parser.add_argument('--volume_path', type=str,
#                     default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS/test', 
#                     help='root dir for validation volume data')

# [修改点] 将路径改为数据集的根目录（去掉末尾的 /test）
# 因为代码会在后面自动拼接上 split (即 "test")，这样就会组合成正确的路径 .../data/OCTA-SS/test
parser.add_argument('--volume_path', type=str,
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS', 
                    help='root dir for validation volume data')

parser.add_argument('--dataset', type=str,
                    default='OCTA-SS', help='experiment_name')
parser.add_argument('--num_classes', type=int,
                    default=2, help='output channel of network')
parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')

parser.add_argument('--max_iterations', type=int,default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int, default=150, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=24,
                    help='batch_size per gpu')
parser.add_argument('--img_size', type=int, default=224, help='input patch size of network input')
parser.add_argument('--is_savenii', action="store_true", help='whether to save results during inference')

parser.add_argument('--n_skip', type=int, default=3, help='using number of skip-connect, default is num')
parser.add_argument('--vit_name', type=str, default='R50-ViT-B_16', help='select one vit model')

parser.add_argument('--test_save_dir', type=str, 
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS/test/result', 
                    help='saving prediction as nii!')

parser.add_argument('--deterministic', type=int,  default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.01, help='segmentation network learning rate')
parser.add_argument('--seed', type=int, default=1234, help='random seed')
parser.add_argument('--vit_patches_size', type=int, default=16, help='vit_patches_size, default is 16')
args = parser.parse_args()


def inference(args, model, test_save_path=None):
    # [修改点2] 使用新的 Dataset 类
    # 如果你的 dataset_OCTA_SS 不需要 list_dir 参数，这里传入也不会报错(除非__init__里强制检查)
    # 这里的 split="test" 也是为了适配你的 dataset 逻辑

    # db_test = args.Dataset(base_dir=args.volume_path, split="test", list_dir=args.list_dir)
    db_test = args.Dataset(base_dir=args.volume_path, split="test")
    
    testloader = DataLoader(db_test, batch_size=1, shuffle=False, num_workers=1)
    logging.info("{} test iterations per epoch".format(len(testloader)))
    model.eval()
    metric_list = 0.0
    # ... 上面的代码不变 ...
    for i_batch, sampled_batch in tqdm(enumerate(testloader)):
        # image, label, case_name = sampled_batch["image"], sampled_batch["label"], sampled_batch['case_name'][0]
        
        # === 修改开始 ===
        image = sampled_batch["image"]
        label = sampled_batch["label"]
        case_name = sampled_batch['case_name'][0]

        # 如果数据是 3 维 (Batch, H, W)，我们需要扩展为 4 维 (Batch, 1, H, W)
        # 这样 utils.py 里的 test_single_volume 才会把它当做只有 1 个切片的 3D 数据处理
        if len(image.shape) == 3:
            image = image.unsqueeze(1)
        if len(label.shape) == 3:
            label = label.unsqueeze(1)
        # === 修改结束 ===

        # 注意：这里 h, w 获取逻辑可能也需要根据实际维度微调，通常 utils.py 会自己处理
        # 只要传入的是 (B, 1, H, W)，test_single_volume 就能正常工作
        
        metric_i = test_single_volume(image, label, model, classes=args.num_classes, patch_size=[args.img_size, args.img_size],
                                      test_save_path=test_save_path, case=case_name, z_spacing=args.z_spacing)
        
        # ... 下面的代码不变 ...
        metric_list += np.array(metric_i)
        logging.info('idx %d case %s mean_dice %f mean_hd95 %f' % (i_batch, case_name, np.mean(metric_i, axis=0)[0], np.mean(metric_i, axis=0)[1]))
    metric_list = metric_list / len(db_test)
    for i in range(1, args.num_classes):
        logging.info('Mean class %d mean_dice %f mean_hd95 %f' % (i, metric_list[i-1][0], metric_list[i-1][1]))
    performance = np.mean(metric_list, axis=0)[0]
    mean_hd95 = np.mean(metric_list, axis=0)[1]
    logging.info('Testing performance in best val model: mean_dice : %f mean_hd95 : %f' % (performance, mean_hd95))
    return "Testing Finished!"


if __name__ == "__main__":

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    # [修改点3] 注册新的 Dataset
    dataset_config = {
        'OCTA-SS': {
            'Dataset': Octa_SS_dataset, # 使用上方 import 的类
            'volume_path': args.volume_path,
            'list_dir': args.list_dir,
            'num_classes': 2,
            'z_spacing': 1,
        },
    }
    
    dataset_name = 'OCTA-SS' 
    args.dataset = dataset_name
    
    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.volume_path = dataset_config[dataset_name]['volume_path']
    args.Dataset = dataset_config[dataset_name]['Dataset']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.z_spacing = dataset_config[dataset_name]['z_spacing']
    args.is_pretrain = True

    args.exp = 'TU_' + dataset_name + str(args.img_size)
    
    snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model/TU_OCTA-SS224/OCTA-SSm1/epoch_149.pth"

    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip
    config_vit.patches.size = (args.vit_patches_size, args.vit_patches_size)
    if args.vit_name.find('R50') !=-1:
        config_vit.patches.grid = (int(args.img_size/args.vit_patches_size), int(args.img_size/args.vit_patches_size))
    
    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()

    snapshot = snapshot_path
    if not os.path.exists(snapshot):
        print(f"Error: Weight file not found at {snapshot}")
        sys.exit(1)
        
    net.load_state_dict(torch.load(snapshot))
    print(f"Loaded model from {snapshot}")
    
    snapshot_name = snapshot_path.split('/')[-1]

    log_folder = './test_log/test_log_' + args.exp
    os.makedirs(log_folder, exist_ok=True)
    logging.basicConfig(filename=log_folder + '/'+snapshot_name+".txt", level=logging.INFO, format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    logging.info(snapshot_name)

    args.is_savenii = True 
    args.test_save_dir = '/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA-SS/test/result1'
    
    test_save_path = args.test_save_dir
    os.makedirs(test_save_path, exist_ok=True)
    
    inference(args, net, test_save_path)