import os
import random
import numpy as np
import torch
from scipy import ndimage
from scipy.ndimage import zoom
from torch.utils.data import Dataset
from PIL import Image

def random_rot_flip(image, label):
    k = np.random.randint(0, 4)
    image = np.rot90(image, k)
    label = np.rot90(label, k)
    axis = np.random.randint(0, 2)
    image = np.flip(image, axis=axis).copy()
    label = np.flip(label, axis=axis).copy()
    return image, label

def random_rotate(image, label):
    angle = np.random.randint(-20, 20)
    image = ndimage.rotate(image, angle, order=0, reshape=False)
    label = ndimage.rotate(label, angle, order=0, reshape=False)
    return image, label

class RandomGenerator(object):
    def __init__(self, output_size):
        self.output_size = output_size

    def __call__(self, sample):
        image, label = sample['image'], sample['label']

        if random.random() > 0.5:
            image, label = random_rot_flip(image, label)
        elif random.random() > 0.5:
            image, label = random_rotate(image, label)
            
        x, y = image.shape
        if x != self.output_size[0] or y != self.output_size[1]:
            # 这里的order=3用于图像插值，order=0用于标签插值
            image = zoom(image, (self.output_size[0] / x, self.output_size[1] / y), order=3)
            label = zoom(label, (self.output_size[0] / x, self.output_size[1] / y), order=0)
            
        image = torch.from_numpy(image.astype(np.float32)).unsqueeze(0)
        label = torch.from_numpy(label.astype(np.float32))
        sample = {'image': image, 'label': label.long()}
        return sample

class Drive_dataset(Dataset):
    def __init__(self, base_dir, split, transform=None):
        """
        base_dir: 数据集根目录，例如 /home/ly_s/WORK/Segment/TransUNet-main/data/DRIVE
        split: 'train' 或 'test'
        """
        self.transform = transform
        self.split = split
        self.data_dir = base_dir
        
        # 1. 定义原图和Mask的具体路径
        # 根据您提供的目录结构: DRIVE/train/image 和 DRIVE/train/mask
        self.img_dir = os.path.join(self.data_dir, self.split, 'image')
        self.mask_dir = os.path.join(self.data_dir, self.split, 'mask')
        
        # 2. 读取所有图片文件列表
        # DRIVE 数据集通常是 .tif 或 .png，这里做通用处理
        self.image_files = []
        for f in os.listdir(self.img_dir):
            if f.endswith('.tif') or f.endswith('.png') or f.endswith('.jpg'):
                self.image_files.append(f)
        
        self.image_files.sort()
        print(f"Found {len(self.image_files)} images in {self.split} set.")

    def __len__(self):
        return len(self.image_files)

    def __getitem__(self, idx):
        img_filename = self.image_files[idx]
        
        # 3. 尝试寻找对应的 Mask 文件
        # 注意：DRIVE数据集的文件名可能有对应关系，比如 "01_test.tif" 对应 "01_test_manual1.gif"
        # 或者在您的整理中，文件名是完全一致的 (01.png 对应 01.png)
        # 这里使用一种比较鲁棒的方法：假设文件名(不含扩展名)是包含关系的，或者完全一致的。
        
        basename = os.path.splitext(img_filename)[0]
        
        # 在 mask 目录下寻找匹配的文件
        mask_filename = None
        if os.path.exists(os.path.join(self.mask_dir, img_filename)):
            # 情况1：文件名完全一致 (01.tif -> 01.tif)
            mask_filename = img_filename
        elif os.path.exists(os.path.join(self.mask_dir, basename + '.png')):
             # 情况2：同名但扩展名为 png (01.tif -> 01.png)
            mask_filename = basename + '.png'
        elif os.path.exists(os.path.join(self.mask_dir, basename + '.gif')):
             # 情况3：DRIVE 原始标签通常是 gif (01_test.tif -> 01_test_manual1.gif，这里简化为同名gif)
             mask_filename = basename + '.gif'
        else:
            # 情况4：遍历 mask 目录寻找前缀匹配的文件 (处理 _manual1 后缀情况)
            # 例如 img: 21_training.tif, mask: 21_manual1.gif
            # 提取数字 ID: 21
            img_id = basename.split('_')[0] 
            for f in os.listdir(self.mask_dir):
                if f.startswith(img_id) and ('manual1' in f or 'mask' in f):
                    mask_filename = f
                    break
            # 如果还找不到，尝试找任意以 img_id 开头的文件
            if mask_filename is None:
                for f in os.listdir(self.mask_dir):
                    if f.startswith(img_id):
                        mask_filename = f
                        break
        
        if mask_filename is None:
            raise FileNotFoundError(f"Cannot find mask for image {img_filename} in {self.mask_dir}")

        # 4. 读取路径
        img_path = os.path.join(self.img_dir, img_filename)
        mask_path = os.path.join(self.mask_dir, mask_filename)
        
        # 5. 读取图像
        # 眼底图像如果是彩色的，建议读取 RGB，然后 Transforms 里可以做灰度处理
        # 但 TransUNet 这种结构如果输入通道是 3，这里就保持 RGB；如果是 1，就 convert('L')
        # 参考 OCTA 代码，这里默认转为灰度图 'L'，因为视网膜血管分割通常只需要绿通道或灰度图
        image = Image.open(img_path).convert('RGB') 
        # 提取绿色通道 (Green channel) 通常对比度最高，或者直接转灰度
        r, g, b = image.split()
        image = g # 使用绿色通道
        # image = image.convert('L') # 或者直接转灰度
        
        label = Image.open(mask_path).convert('L')
        
        # 6. 转为 numpy 并归一化
        image = np.array(image).astype(np.float32) / 255.0
        label = np.array(label).astype(np.float32)
        
        # 7. 标签二值化
        label = label / 255.0
        label[label >= 0.5] = 1
        label[label < 0.5] = 0
        
        sample = {'image': image, 'label': label}
        
        # 8. 应用变换
        if self.transform:
            sample = self.transform(sample)
            
        # 9. 测试集处理 (如果没有 transform)
        if not self.transform and self.split == "test":
             image_tensor = torch.from_numpy(image).unsqueeze(0).float()
             label_tensor = torch.from_numpy(label).long()
             sample = {'image': image_tensor, 'label': label_tensor}

        sample['case_name'] = basename
        return sample