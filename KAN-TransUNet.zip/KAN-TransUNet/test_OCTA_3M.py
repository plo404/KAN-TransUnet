import argparse
import logging
import os
import random
import sys
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

# [修改点1] 导入 Dataset 类
# 假设 OCTA-3M 的文件结构与 OCTA-SS 一致（train/test下都有 original/segment 文件夹）
# 我们直接复用 Octa_SS_dataset。如果您的 dataset 文件名不同，请修改此处。
from datasets.dataset_OCTA_3M import OCTA_3M_dataset 

from utils import test_single_volume
from networks.vit_seg_modeling0 import VisionTransformer as ViT_seg
from networks.vit_seg_modeling0 import CONFIGS as CONFIGS_ViT_seg

parser = argparse.ArgumentParser()

# [修改点2] 设置 OCTA-3M 数据集的根目录
# 程序会自动读取该目录下的 test/original 和 test/segment
parser.add_argument('--volume_path', type=str,
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M', 
                    help='root dir for validation volume data')

parser.add_argument('--dataset', type=str,
                    default='OCTA-3M', help='experiment_name')
parser.add_argument('--num_classes', type=int,
                    default=2, help='output channel of network')
parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')

parser.add_argument('--max_iterations', type=int,default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int, default=150, help='maximum epoch number to train')
parser.add_argument('--batch_size', type=int, default=24,
                    help='batch_size per gpu')
parser.add_argument('--img_size', type=int, default=224, help='input patch size of network input')
parser.add_argument('--is_savenii', action="store_true", help='whether to save results during inference')

parser.add_argument('--n_skip', type=int, default=3, help='using number of skip-connect, default is num')

# [修改点3] 确认模型架构
# 您的训练路径 "TU_OCTA_3M224" 通常由 R50-ViT-B_16 生成。
# 如果您确定是用 ViT-L_32 训练的，请手动改为 'ViT-L_32'










parser.add_argument('--vit_name', type=str, default='ViT-L_32', help='select one vit model')
# parser.add_argument('--vit_name', type=str, default='ViT-L_32', help='select one vit model')


'''
    'ViT-B_16'
    'ViT-B_32'
    'ViT-L_16'
    'ViT-L_32'
    'ViT-H_14'
    'R50-ViT-B_16'
    'R50-ViT-L_16'
'''












# [修改点4] 设置结果保存路径
parser.add_argument('--test_save_dir', type=str, 
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M/test/ViT-L_32', 
                    help='saving prediction as nii!')

# # [修改点4] 设置结果保存路径
# parser.add_argument('--test_save_dir', type=str, 
#                     default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M/test/result0', 
#                     help='saving prediction as nii!')






parser.add_argument('--deterministic', type=int,  default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.01, help='segmentation network learning rate')
parser.add_argument('--seed', type=int, default=1234, help='random seed')

# [修改点5] Patch Size 设置
# R50-ViT-B_16 默认通常是 16。如果您使用的是 ViT-L_32，通常是 32。
# 这里默认设为 16 以匹配 R50-ViT-B_16。





parser.add_argument('--vit_patches_size', type=int, default=32, help='vit_patches_size, default is 16')
# parser.add_argument('--vit_patches_size', type=int, default=32, help='vit_patches_size, default is 16')







args = parser.parse_args()


def inference(args, model, test_save_path=None):
    # 使用 dataset_OCTA_SS 中定义的 Dataset 类
    # split="test" 会让 DataLoader 寻找 volume_path/test 目录
    db_test = args.Dataset(base_dir=args.volume_path, split="test")
    
    testloader = DataLoader(db_test, batch_size=1, shuffle=False, num_workers=1)
    logging.info("{} test iterations per epoch".format(len(testloader)))
    model.eval()
    metric_list = 0.0
    
    for i_batch, sampled_batch in tqdm(enumerate(testloader)):
        # 获取数据
        image = sampled_batch["image"]
        label = sampled_batch["label"]
        case_name = sampled_batch['case_name'][0]

        # 维度调整：确保输入 utils.test_single_volume 的数据是 (Batch, 1, H, W)
        if len(image.shape) == 3:
            image = image.unsqueeze(1)
        if len(label.shape) == 3:
            label = label.unsqueeze(1)
        
        # 调用测试函数
        # 注意：args.img_size 默认为 224，如果您的测试图片尺寸不同，
        # test_single_volume 内部通常会处理缩放或切片，或者由下面的 ResizeWrapper 处理
        metric_i = test_single_volume(image, label, model, classes=args.num_classes, patch_size=[args.img_size, args.img_size],
                                      test_save_path=test_save_path, case=case_name, z_spacing=args.z_spacing)
        
        metric_list += np.array(metric_i)
        logging.info('idx %d case %s mean_dice %f mean_hd95 %f' % (i_batch, case_name, np.mean(metric_i, axis=0)[0], np.mean(metric_i, axis=0)[1]))
    
    metric_list = metric_list / len(db_test)
    for i in range(1, args.num_classes):
        logging.info('Mean class %d mean_dice %f mean_hd95 %f' % (i, metric_list[i-1][0], metric_list[i-1][1]))
    performance = np.mean(metric_list, axis=0)[0]
    mean_hd95 = np.mean(metric_list, axis=0)[1]
    logging.info('Testing performance in best val model: mean_dice : %f mean_hd95 : %f' % (performance, mean_hd95))
    return "Testing Finished!"


if __name__ == "__main__":

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    # [修改点6] 注册 OCTA-3M 数据集配置
    dataset_config = {
        'OCTA-3M': {
            'Dataset': OCTA_3M_dataset, # 复用 Dataset 类
            'volume_path': args.volume_path, # 对应 /home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M
            'list_dir': args.list_dir,
            'num_classes': 2,
            'z_spacing': 1,
        },
    }
    
    dataset_name = args.dataset # 默认为 OCTA-3M
    
    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.volume_path = dataset_config[dataset_name]['volume_path']
    args.Dataset = dataset_config[dataset_name]['Dataset']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.z_spacing = dataset_config[dataset_name]['z_spacing']
    args.is_pretrain = True

    args.exp = 'TU_' + dataset_name + str(args.img_size)
    





    # [修改点7] 指定权重文件绝对路径
    # snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model/TU_OCTA_3M224/OCTA_3M/epoch_149.pth"


    snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model/TU_OCTA_3M224/TU_ViT-L_32_skip3_vitpatch32_epo150_bs4_224/epoch_149.pth"







    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip
    config_vit.patches.size = (args.vit_patches_size, args.vit_patches_size)

    # R50-ViT-B_16 的 grid 配置
    if args.vit_name.find('R50') != -1:
        config_vit.patches.grid = (int(args.img_size / args.vit_patches_size), int(args.img_size / args.vit_patches_size))
    
    # 手动指定 skip_channels (针对 R50-ViT-B_16)
    if 'R50' in args.vit_name:
        config_vit.skip_channels = [512, 256, 64, 16]
    else:
        config_vit.skip_channels = [0, 0, 0, 0]

    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()

    # 检查权重文件是否存在
    snapshot = snapshot_path
    if not os.path.exists(snapshot):
        print(f"Error: Weight file not found at {snapshot}")
        sys.exit(1)
        
    # 加载权重
    # 如果遇到 key 不匹配错误（比如 module. 前缀），可能需要修改 key 名称
    net.load_state_dict(torch.load(snapshot))
    print(f"Loaded model from {snapshot}")
    
    snapshot_name = snapshot_path.split('/')[-1]

    log_folder = './test_log/test_log_' + args.exp
    os.makedirs(log_folder, exist_ok=True)
    logging.basicConfig(filename=log_folder + '/'+snapshot_name+".txt", level=logging.INFO, format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    logging.info(snapshot_name)

    args.is_savenii = True 
    args.test_save_dir = parser.parse_args().test_save_dir # 重新确保使用 argument 中的路径
    
    test_save_path = args.test_save_dir
    os.makedirs(test_save_path, exist_ok=True)
    print(f"Results will be saved to: {test_save_path}")

    # [Resize Wrapper] 
    # 这是一个保护措施，防止网络输出尺寸与原图不一致（由于 Patch Size 整除问题）。
    # 它会将输出强制插值回输入尺寸。
    import torch.nn.functional as F
    class ResizeWrapper(nn.Module):
        def __init__(self, model): super().__init__(); self.model = model
        def forward(self, x): 
            return F.interpolate(self.model(x), size=x.shape[-2:], mode='bilinear', align_corners=False)

    net = ResizeWrapper(net) 
    
    inference(args, net, test_save_path)