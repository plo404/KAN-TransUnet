import argparse
import logging
import os
import random
import sys
import copy  # [新增] 用于备份模型权重
import numpy as np
import torch
import torch.backends.cudnn as cudnn
import torch.nn as nn
import torch.optim as optim # [新增] 优化器
import torch.nn.functional as F
from torch.utils.data import DataLoader
from tqdm import tqdm

# [修改点1] 导入 Dataset 类
from datasets.dataset_OCTA_3M import OCTA_3M_dataset 

from utils import test_single_volume
from networks.vit_seg_modeling import VisionTransformer as ViT_seg
from networks.vit_seg_modeling import CONFIGS as CONFIGS_ViT_seg

# -------------------- TENT 超参数默认值 --------------------
TENT_STEPS = 5        # 适配步数
TENT_LR = 1e-4        # 学习率
TENT_OPTIM = "Adam"   
REG_LAMBDA = 1e-3     # L2 回拉强度
# ---------------------------------------------------------

parser = argparse.ArgumentParser()

# [修改点2] 设置 OCTA-3M 数据集的根目录
parser.add_argument('--volume_path', type=str,
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M', 
                    help='root dir for validation volume data')

parser.add_argument('--dataset', type=str,
                    default='OCTA-3M', help='experiment_name')
parser.add_argument('--num_classes', type=int,
                    default=2, help='output channel of network')
parser.add_argument('--list_dir', type=str,
                    default='./lists/lists_Synapse', help='list dir')

parser.add_argument('--max_iterations', type=int,default=30000, help='maximum epoch number to train')
parser.add_argument('--max_epochs', type=int, default=150, help='maximum epoch number to train')

parser.add_argument('--batch_size', type=int, default=4,
                    help='batch_size per gpu')

parser.add_argument('--img_size', type=int, default=224, help='input patch size of network input')

parser.add_argument('--is_savenii', action="store_true", help='whether to save results during inference')

parser.add_argument('--n_skip', type=int, default=3, help='using number of skip-connect, default is num')

# [修改点3] 确认模型架构
parser.add_argument('--vit_name', type=str, default='R50-ViT-B_16', help='select one vit model')

# [修改点4] 设置结果保存路径
parser.add_argument('--test_save_dir', type=str, 
                    default='/home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M/test/result1', 
                    help='saving prediction as nii!')

parser.add_argument('--deterministic', type=int,  default=1, help='whether use deterministic training')
parser.add_argument('--base_lr', type=float,  default=0.01, help='segmentation network learning rate')
parser.add_argument('--seed', type=int, default=1234, help='random seed')

# [修改点5] Patch Size 设置
parser.add_argument('--vit_patches_size', type=int, default=16, help='vit_patches_size, default is 16')

# [新增] TENT 相关参数
parser.add_argument('--tent_steps', type=int, default=TENT_STEPS, help='TENT adaptation steps')
parser.add_argument('--tent_lr', type=float, default=TENT_LR, help='TENT learning rate')

args = parser.parse_args()


# ==========================================================================================
#  TENT 模块实现 (完全复用之前的逻辑)
# ==========================================================================================

def get_tent_params(model):
    """
    收集需要更新的参数：优先 BN 层的 weight/bias，如果没有则回退到最后的可训练参数。
    """
    # 1. 冻结所有参数
    for p in model.parameters():
        p.requires_grad = False

    tent_params = []
    # 2. 尝试寻找 BatchNorm 层 (TransUNet 的 CNN Decoder 部分通常有 BN)
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
            if m.weight is not None:
                m.weight.requires_grad = True
                tent_params.append(m.weight)
            if m.bias is not None:
                m.bias.requires_grad = True
                tent_params.append(m.bias)

    # 3. 后备机制：如果没找到 BN (比如纯 ViT)，则取最后部分的参数
    if len(tent_params) == 0:
        logging.info("TENT Warning: No BatchNorm found. Fallback to updating last layers.")
        named = list(model.named_parameters())
        count = 0
        # 取最后 4 个参数（通常是 segmentation head 的 weight/bias）
        for name, p in reversed(named):
            if not p.requires_grad:
                p.requires_grad = True
                tent_params.append(p)
                count += 1
            if count >= 4:
                break

    return tent_params

def backup_bn_stats(model):
    """备份 BN 统计量 (running_mean, running_var)"""
    backups = []
    for m in model.modules():
        if isinstance(m, (nn.BatchNorm1d, nn.BatchNorm2d, nn.BatchNorm3d)):
            if hasattr(m, 'running_mean') and hasattr(m, 'running_var'):
                backups.append((m, m.running_mean.clone(), m.running_var.clone()))
    return backups

def restore_bn_stats(backups):
    """恢复 BN 统计量"""
    for m, rm, rv in backups:
        m.running_mean.data.copy_(rm)
        m.running_var.data.copy_(rv)

def tent_adapt_segmentation(model, image, steps, lr, optimizer_name=TENT_OPTIM, reg_lambda=REG_LAMBDA):
    """
    针对分割任务的 TENT 适配。
    image: (B, C, H, W)
    """
    # 获取可更新参数
    tent_params = get_tent_params(model)
    if len(tent_params) == 0:
        return

    # 备份 BN 统计量 (防止污染全局统计)
    bn_backups = backup_bn_stats(model)
    
    # 备份参数初始值 (用于 L2 回拉)
    orig_vals = {p: p.detach().clone() for p in tent_params} if reg_lambda > 0 else {}

    # 开启训练模式 (允许梯度更新)
    model.train() 

    # 优化器
    if optimizer_name.lower() == "sgd":
        optimizer = torch.optim.SGD(tent_params, lr=lr, momentum=0.9)
    else:
        optimizer = torch.optim.Adam(tent_params, lr=lr)

    for _ in range(steps):
        optimizer.zero_grad()
        
        # 前向传播
        outputs = model(image) # (B, Num_Classes, H, W)
        
        # --- 熵最小化损失 (针对分割图) ---
        # 1. Softmax
        probs = torch.softmax(outputs, dim=1) 
        
        # 2. 计算像素级熵: -sum(p * log(p))
        # dim=1 是类别通道
        entropy = -torch.sum(probs * torch.log(probs + 1e-12), dim=1) # 结果 shape: (B, H, W)
        
        # 3. 对全图求平均作为 Loss
        loss = entropy.mean()

        # --- L2 正则回拉 ---
        if reg_lambda > 0:
            reg = 0.0
            for p in tent_params:
                reg = reg + (p - orig_vals[p]).pow(2).sum()
            loss = loss + reg_lambda * reg

        # 反向传播更新
        loss.backward()
        optimizer.step()

    # 恢复 BN 统计量，并切回 Eval 模式
    # 注意：此时 weights 已经被更新了，适合接下来的 inference 使用
    restore_bn_stats(bn_backups)
    model.eval()

# ==========================================================================================


def inference(args, model, test_save_path=None):
    # 使用 dataset_OCTA_SS 中定义的 Dataset 类
    db_test = args.Dataset(base_dir=args.volume_path, split="test")
    
    testloader = DataLoader(db_test, batch_size=1, shuffle=False, num_workers=1)
    logging.info("{} test iterations per epoch".format(len(testloader)))
    
    # [TENT 修改 1] 备份初始模型状态
    logging.info("Backing up initial model state for episodic adaptation...")
    initial_model_state = copy.deepcopy(model.state_dict())

    metric_list = 0.0
    
    for i_batch, sampled_batch in tqdm(enumerate(testloader)):
        # 获取数据
        image = sampled_batch["image"]
        label = sampled_batch["label"]
        case_name = sampled_batch['case_name'][0]

        # 维度调整：确保输入 utils.test_single_volume 的数据是 (Batch, 1, H, W)
        if len(image.shape) == 3:
            image = image.unsqueeze(1)
        if len(label.shape) == 3:
            label = label.unsqueeze(1)
        
        # ------------------- [TENT 修改 2] Adaptation Loop Start -------------------
        # 1. 每次推理前，重置模型到初始状态 (Episodic)
        model.load_state_dict(initial_model_state)
        
        # 2. 准备数据
        image_cuda = image.cuda()
        
        # 3. 强制 Resize 到 224x224 (因为 ViT 需要固定的 Patch 数量)
        if image_cuda.size(2) != args.img_size or image_cuda.size(3) != args.img_size:
            image_tent = F.interpolate(image_cuda, size=(args.img_size, args.img_size), 
                                     mode='bilinear', align_corners=False)
        else:
            image_tent = image_cuda
        
        # 4. 执行 TENT 适配
        tent_adapt_segmentation(model, image_tent, steps=args.tent_steps, lr=args.tent_lr)
        # ------------------- Adaptation Loop End -----------------------------------

        # 调用测试函数
        # 注意：args.img_size 默认为 224，如果您的测试图片尺寸不同，
        # test_single_volume 内部通常会处理缩放或切片，或者由下面的 ResizeWrapper 处理
        metric_i = test_single_volume(image, label, model, classes=args.num_classes, patch_size=[args.img_size, args.img_size],
                                      test_save_path=test_save_path, case=case_name, z_spacing=args.z_spacing)
        
        metric_list += np.array(metric_i)
        logging.info('idx %d case %s mean_dice %f mean_hd95 %f' % (i_batch, case_name, np.mean(metric_i, axis=0)[0], np.mean(metric_i, axis=0)[1]))
    
    metric_list = metric_list / len(db_test)
    for i in range(1, args.num_classes):
        logging.info('Mean class %d mean_dice %f mean_hd95 %f' % (i, metric_list[i-1][0], metric_list[i-1][1]))
    performance = np.mean(metric_list, axis=0)[0]
    mean_hd95 = np.mean(metric_list, axis=0)[1]
    logging.info('Testing performance in best val model: mean_dice : %f mean_hd95 : %f' % (performance, mean_hd95))
    return "Testing Finished!"


if __name__ == "__main__":

    if not args.deterministic:
        cudnn.benchmark = True
        cudnn.deterministic = False
    else:
        cudnn.benchmark = False
        cudnn.deterministic = True
    random.seed(args.seed)
    np.random.seed(args.seed)
    torch.manual_seed(args.seed)
    torch.cuda.manual_seed(args.seed)

    # [修改点6] 注册 OCTA-3M 数据集配置
    dataset_config = {
        'OCTA-3M': {
            'Dataset': OCTA_3M_dataset, # 复用 Dataset 类
            'volume_path': args.volume_path, # 对应 /home/ly_s/WORK/Segment/TransUNet-main/data/OCTA_3M
            'list_dir': args.list_dir,
            'num_classes': 2,
            'z_spacing': 1,
        },
    }
    
    dataset_name = args.dataset # 默认为 OCTA-3M
    
    args.num_classes = dataset_config[dataset_name]['num_classes']
    args.volume_path = dataset_config[dataset_name]['volume_path']
    args.Dataset = dataset_config[dataset_name]['Dataset']
    args.list_dir = dataset_config[dataset_name]['list_dir']
    args.z_spacing = dataset_config[dataset_name]['z_spacing']
    args.is_pretrain = True

    args.exp = 'TU_' + dataset_name + str(args.img_size)

    # [修改点7] 指定权重文件绝对路径
    snapshot_path = "/home/ly_s/WORK/Segment/TransUNet-main/model/TU_OCTA_3M224/OCTA_3M-m1/epoch_149.pth"

    config_vit = CONFIGS_ViT_seg[args.vit_name]
    config_vit.n_classes = args.num_classes
    config_vit.n_skip = args.n_skip
    config_vit.patches.size = (args.vit_patches_size, args.vit_patches_size)

    # R50-ViT-B_16 的 grid 配置
    if args.vit_name.find('R50') != -1:
        config_vit.patches.grid = (int(args.img_size / args.vit_patches_size), int(args.img_size / args.vit_patches_size))
    
    # 手动指定 skip_channels (针对 R50-ViT-B_16)
    if 'R50' in args.vit_name:
        config_vit.skip_channels = [512, 256, 64, 16]
    else:
        config_vit.skip_channels = [0, 0, 0, 0]

    net = ViT_seg(config_vit, img_size=args.img_size, num_classes=config_vit.n_classes).cuda()

    # 检查权重文件是否存在
    snapshot = snapshot_path
    if not os.path.exists(snapshot):
        print(f"Error: Weight file not found at {snapshot}")
        sys.exit(1)
        
    # 加载权重
    net.load_state_dict(torch.load(snapshot))
    print(f"Loaded model from {snapshot}")
    
    snapshot_name = snapshot_path.split('/')[-1]

    log_folder = './test_log/test_log_' + args.exp
    os.makedirs(log_folder, exist_ok=True)
    
    # [TENT 修改 3] 日志文件名增加 TENT 标识
    logging.basicConfig(filename=log_folder + '/'+snapshot_name+"_TENT.txt", level=logging.INFO, format='[%(asctime)s.%(msecs)03d] %(message)s', datefmt='%H:%M:%S')
    
    logging.getLogger().addHandler(logging.StreamHandler(sys.stdout))
    logging.info(str(args))
    logging.info(snapshot_name)
    logging.info(f"TENT enabled: steps={args.tent_steps}, lr={args.tent_lr}")

    args.is_savenii = True 
    args.test_save_dir = parser.parse_args().test_save_dir # 重新确保使用 argument 中的路径
    
    test_save_path = args.test_save_dir
    os.makedirs(test_save_path, exist_ok=True)
    print(f"Results will be saved to: {test_save_path}")

    # [Resize Wrapper] 
    import torch.nn.functional as F
    class ResizeWrapper(nn.Module):
        def __init__(self, model): super().__init__(); self.model = model
        def forward(self, x): 
            return F.interpolate(self.model(x), size=x.shape[-2:], mode='bilinear', align_corners=False)

    net = ResizeWrapper(net) 
    
    inference(args, net, test_save_path)